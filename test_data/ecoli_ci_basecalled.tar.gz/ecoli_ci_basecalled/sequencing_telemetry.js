[
    {
        "aggregation": "segment", 
        "analysis_id": "ffa802df-91b1-475c-b9d5-5dc3d2df847c", 
        "basecall_1d": {
            "exit_status_dist": {
                "pass": 1
            }, 
            "qscore_dist_temp": [
                {
                    "count": 1, 
                    "mean_qscore": 10.0
                }
            ], 
            "qscore_sum_temp": {
                "count": 1, 
                "mean": 10.406210899353027, 
                "sum": 10.406210899353027
            }, 
            "read_len_events_sum_temp": 25440, 
            "seq_len_bases_dist_temp": [
                {
                    "count": 1, 
                    "length": 0.0
                }
            ], 
            "seq_len_bases_sum_temp": 1, 
            "seq_len_events_dist_temp": [
                {
                    "count": 1, 
                    "length": 25000.0
                }
            ], 
            "speed_bases_per_second_dist_temp": [
                {
                    "count": 1, 
                    "speed": 1.0
                }
            ], 
            "strand_median_pa": {
                "count": 1, 
                "mean": 96.61366271972656, 
                "sum": 96.61366271972656
            }, 
            "strand_sd_pa": {
                "count": 1, 
                "mean": 9.434245109558105, 
                "sum": 9.434245109558105
            }
        }, 
        "channel_count": 1, 
        "context_tags": {
            "experiment_kit": "genomic_dna", 
            "filename": "kelvin_20160617_fn_mn17519_sequencing_run_sample_id_74930", 
            "sample_frequency": "4000", 
            "user_filename_input": "sample_id"
        }, 
        "latest_run_time": 19980.818359375, 
        "levels_sums": {
            "count": 1, 
            "mean": 0.0, 
            "open_pore_level_sum": 0.0
        }, 
        "opts": {
            "adapter_pt_range_scale": "5.200000", 
            "additional_context_bases": "2", 
            "align_ref": "", 
            "align_type": "auto", 
            "allow_inferior_barcodes": "0", 
            "arrangements_files": "barcode_arrs_pcr12.cfg barcode_arrs_pcr96.cfg barcode_arrs_nb12.cfg barcode_arrs_nb13-24.cfg barcode_arrs_nb24.cfg barcode_arrs_nb96.cfg barcode_arrs_rbk.cfg barcode_arrs_lwb.cfg barcode_arrs_rlb.cfg barcode_arrs_rab.cfg barcode_arrs_rbk4.cfg barcode_arrs_rbk096.cfg barcode_arrs_vmk.cfg barcode_arrs_vmk2.cfg barcode_arrs_16s.cfg", 
            "as_cpu_threads_per_scaler": "2", 
            "as_gpu_runners_per_device": "2", 
            "as_model_file": "", 
            "as_num_scalers": "1", 
            "as_reads_per_runner": "32", 
            "bam_methylation_threshold": "5.000000", 
            "bam_out": "0", 
            "barcode_kits": "", 
            "beam_cut": "100.000000", 
            "beam_width": "32", 
            "bed_file": "", 
            "builtin_scripts": "1", 
            "calib_detect": "0", 
            "calib_max_sequence_length": "3800", 
            "calib_min_coverage": "0.600000", 
            "calib_min_sequence_length": "3000", 
            "calib_reference": "lambda_3.6kb.fasta", 
            "chunk_size": "2000", 
            "chunks_per_caller": "10000", 
            "chunks_per_runner": "256", 
            "client_id": "-1", 
            "compress_fastq": "1", 
            "cpu_threads_per_caller": "4", 
            "detect_mid_strand_adapter": "0", 
            "detect_mid_strand_barcodes": "0", 
            "device": "", 
            "disable_pings": "0", 
            "disable_qscore_filtering": "0", 
            "dmean_threshold": "1.000000", 
            "dmean_win_size": "2", 
            "end_gap1": "40", 
            "end_gap2": "40", 
            "extend_gap1": "40", 
            "extend_gap2": "160", 
            "fast5_out": "1", 
            "flowcell": "", 
            "front_window_size": "150", 
            "gpu_runners_per_device": "4", 
            "high_priority_threshold": "10", 
            "input_file_list": "", 
            "jump_threshold": "1.000000", 
            "kernel_path": "", 
            "kit": "", 
            "lamp_arrangements_files": "barcode_arrs_ncov8.cfg barcode_arrs_ncov96.cfg barcode_arrs_multivirus1.cfg barcode_arrs_multivirus8.cfg", 
            "lamp_kit": "", 
            "log_speed_frequency": "0", 
            "max_queued_reads": "2000", 
            "max_search_len": "1000", 
            "medium_priority_threshold": "4", 
            "min_length_lamp_context": "30", 
            "min_length_lamp_target": "70", 
            "min_qscore": "9.000000", 
            "min_score": "60.000000", 
            "min_score_lamp": "80.000000", 
            "min_score_lamp_mask": "50.000000", 
            "min_score_lamp_target": "50.000000", 
            "min_score_mask": "40.000000", 
            "min_score_mid_barcodes": "50.000000", 
            "min_score_rear_override": "60.000000", 
            "model_file": "template_r9.4.1_450bps_hac.jsn", 
            "nested_output_folder": "0", 
            "noisiest_section_scaling_max_size": "8000", 
            "num_alignment_threads": "4", 
            "num_barcode_threads": "4", 
            "num_barcoding_buffers": "96", 
            "num_callers": "2", 
            "num_extra_bases_trim": "0", 
            "num_mid_barcoding_buffers": "96", 
            "open_gap1": "40", 
            "open_gap2": "160", 
            "overlap": "50", 
            "override_scaling": "0", 
            "ping_segment_duration": "60", 
            "ping_url": "https://ping.oxfordnanoportal.com/basecall", 
            "post_out": "0", 
            "print_workflows": "0", 
            "progress_stats_frequency": "-1.000000", 
            "pt_median_offset": "2.500000", 
            "pt_minimum_read_start_index": "30", 
            "pt_required_adapter_drop": "30.000000", 
            "pt_scaling": "0", 
            "qscore_offset": "-0.172100", 
            "qscore_scale": "0.935600", 
            "quiet": "0", 
            "read_batch_size": "4000", 
            "read_id_list": "", 
            "rear_window_size": "150", 
            "records_per_fastq": "4000", 
            "recursive": "0", 
            "require_barcodes_both_ends": "0", 
            "resume": "0", 
            "reverse_sequence": "0", 
            "scaling_mad": "1.000000", 
            "scaling_med": "0.000000", 
            "score_matrix_filename": "5x5_mismatch_matrix.txt", 
            "start_gap1": "40", 
            "start_gap2": "40", 
            "stay_penalty": "1.000000", 
            "temp_bias": "1.000000", 
            "temp_weight": "1.000000", 
            "trace_categories_logs": "", 
            "trace_domains_config": "", 
            "trace_domains_log": "", 
            "trim_barcodes": "0", 
            "trim_min_events": "3", 
            "trim_strategy": "dna", 
            "trim_threshold": "2.500000", 
            "u_substitution": "0", 
            "verbose_logs": "1"
        }, 
        "read_count": 1, 
        "reads_per_channel_dist": [
            {
                "channel": 138, 
                "count": 1
            }
        ], 
        "run_id": "87b136ffc8ea5a243bdcff637a644011b53b6120", 
        "segment_duration": 60, 
        "segment_number": 6, 
        "segment_type": "guppy-acquisition", 
        "software": {
            "analysis": "1d_basecalling", 
            "name": "guppy-basecalling", 
            "version": "5.0.16+b9fcd7b5b"
        }, 
        "tracking_id": {
            "asic_id": "153816617", 
            "asic_id_17": "69161", 
            "asic_id_eeprom": "1867072", 
            "asic_temp": "31.0771847", 
            "auto_update_source": "https://mirror.oxfordnanoportal.com/software/MinKNOW/", 
            "bream_is_standard": "1", 
            "device_id": "MN17519", 
            "exp_script_hash": "a4e44ab9a2f835443be38062fe79e547271013be", 
            "exp_script_name": "NC_48Hr_Sequencing_Run_FLO_MIN104.py", 
            "exp_script_purpose": "sequencing_run", 
            "exp_start_time": "1466170880", 
            "flow_cell_id": "", 
            "heatsink_temp": "34.0273438", 
            "hostname": "kelvin", 
            "installation_type": "map", 
            "msg_id": "0590d39f-79d0-4792-bbab-4c4455640973", 
            "operating_system": "Windows 6.1", 
            "protocol_run_id": "db0dbed2-2a48-4be5-b5bd-26c042ab3c74", 
            "protocols_version_name": "0.51.3.40", 
            "run_id": "87b136ffc8ea5a243bdcff637a644011b53b6120", 
            "time_stamp": "2021-12-14T14:05:13Z", 
            "version": "0.51.3.40 b201605171140", 
            "version_name": "0.51.3.40 b201605171140"
        }
    }, 
    {
        "aggregation": "segment", 
        "analysis_id": "ffa802df-91b1-475c-b9d5-5dc3d2df847c", 
        "basecall_1d": {
            "exit_status_dist": {
                "fail:qscore_filter": 1
            }, 
            "qscore_dist_temp": [
                {
                    "count": 1, 
                    "mean_qscore": 6.5
                }
            ], 
            "qscore_sum_temp": {
                "count": 1, 
                "mean": 6.811399936676025, 
                "sum": 6.811399936676025
            }, 
            "read_len_events_sum_temp": 31147, 
            "seq_len_bases_dist_temp": [
                {
                    "count": 1, 
                    "length": 0.0
                }
            ], 
            "seq_len_bases_sum_temp": 1, 
            "seq_len_events_dist_temp": [
                {
                    "count": 1, 
                    "length": 31000.0
                }
            ], 
            "speed_bases_per_second_dist_temp": [
                {
                    "count": 1, 
                    "speed": 1.0
                }
            ], 
            "strand_median_pa": {
                "count": 1, 
                "mean": 87.5288314819336, 
                "sum": 87.5288314819336
            }, 
            "strand_sd_pa": {
                "count": 1, 
                "mean": 8.910120964050293, 
                "sum": 8.910120964050293
            }
        }, 
        "channel_count": 1, 
        "context_tags": {
            "experiment_kit": "genomic_dna", 
            "filename": "kelvin_20160617_fn_mn17519_sequencing_run_sample_id_74930", 
            "sample_frequency": "4000", 
            "user_filename_input": "sample_id"
        }, 
        "latest_run_time": 53696.890625, 
        "levels_sums": {
            "count": 1, 
            "mean": 0.0, 
            "open_pore_level_sum": 0.0
        }, 
        "opts": {
            "adapter_pt_range_scale": "5.200000", 
            "additional_context_bases": "2", 
            "align_ref": "", 
            "align_type": "auto", 
            "allow_inferior_barcodes": "0", 
            "arrangements_files": "barcode_arrs_pcr12.cfg barcode_arrs_pcr96.cfg barcode_arrs_nb12.cfg barcode_arrs_nb13-24.cfg barcode_arrs_nb24.cfg barcode_arrs_nb96.cfg barcode_arrs_rbk.cfg barcode_arrs_lwb.cfg barcode_arrs_rlb.cfg barcode_arrs_rab.cfg barcode_arrs_rbk4.cfg barcode_arrs_rbk096.cfg barcode_arrs_vmk.cfg barcode_arrs_vmk2.cfg barcode_arrs_16s.cfg", 
            "as_cpu_threads_per_scaler": "2", 
            "as_gpu_runners_per_device": "2", 
            "as_model_file": "", 
            "as_num_scalers": "1", 
            "as_reads_per_runner": "32", 
            "bam_methylation_threshold": "5.000000", 
            "bam_out": "0", 
            "barcode_kits": "", 
            "beam_cut": "100.000000", 
            "beam_width": "32", 
            "bed_file": "", 
            "builtin_scripts": "1", 
            "calib_detect": "0", 
            "calib_max_sequence_length": "3800", 
            "calib_min_coverage": "0.600000", 
            "calib_min_sequence_length": "3000", 
            "calib_reference": "lambda_3.6kb.fasta", 
            "chunk_size": "2000", 
            "chunks_per_caller": "10000", 
            "chunks_per_runner": "256", 
            "client_id": "-1", 
            "compress_fastq": "1", 
            "cpu_threads_per_caller": "4", 
            "detect_mid_strand_adapter": "0", 
            "detect_mid_strand_barcodes": "0", 
            "device": "", 
            "disable_pings": "0", 
            "disable_qscore_filtering": "0", 
            "dmean_threshold": "1.000000", 
            "dmean_win_size": "2", 
            "end_gap1": "40", 
            "end_gap2": "40", 
            "extend_gap1": "40", 
            "extend_gap2": "160", 
            "fast5_out": "1", 
            "flowcell": "", 
            "front_window_size": "150", 
            "gpu_runners_per_device": "4", 
            "high_priority_threshold": "10", 
            "input_file_list": "", 
            "jump_threshold": "1.000000", 
            "kernel_path": "", 
            "kit": "", 
            "lamp_arrangements_files": "barcode_arrs_ncov8.cfg barcode_arrs_ncov96.cfg barcode_arrs_multivirus1.cfg barcode_arrs_multivirus8.cfg", 
            "lamp_kit": "", 
            "log_speed_frequency": "0", 
            "max_queued_reads": "2000", 
            "max_search_len": "1000", 
            "medium_priority_threshold": "4", 
            "min_length_lamp_context": "30", 
            "min_length_lamp_target": "70", 
            "min_qscore": "9.000000", 
            "min_score": "60.000000", 
            "min_score_lamp": "80.000000", 
            "min_score_lamp_mask": "50.000000", 
            "min_score_lamp_target": "50.000000", 
            "min_score_mask": "40.000000", 
            "min_score_mid_barcodes": "50.000000", 
            "min_score_rear_override": "60.000000", 
            "model_file": "template_r9.4.1_450bps_hac.jsn", 
            "nested_output_folder": "0", 
            "noisiest_section_scaling_max_size": "8000", 
            "num_alignment_threads": "4", 
            "num_barcode_threads": "4", 
            "num_barcoding_buffers": "96", 
            "num_callers": "2", 
            "num_extra_bases_trim": "0", 
            "num_mid_barcoding_buffers": "96", 
            "open_gap1": "40", 
            "open_gap2": "160", 
            "overlap": "50", 
            "override_scaling": "0", 
            "ping_segment_duration": "60", 
            "ping_url": "https://ping.oxfordnanoportal.com/basecall", 
            "post_out": "0", 
            "print_workflows": "0", 
            "progress_stats_frequency": "-1.000000", 
            "pt_median_offset": "2.500000", 
            "pt_minimum_read_start_index": "30", 
            "pt_required_adapter_drop": "30.000000", 
            "pt_scaling": "0", 
            "qscore_offset": "-0.172100", 
            "qscore_scale": "0.935600", 
            "quiet": "0", 
            "read_batch_size": "4000", 
            "read_id_list": "", 
            "rear_window_size": "150", 
            "records_per_fastq": "4000", 
            "recursive": "0", 
            "require_barcodes_both_ends": "0", 
            "resume": "0", 
            "reverse_sequence": "0", 
            "scaling_mad": "1.000000", 
            "scaling_med": "0.000000", 
            "score_matrix_filename": "5x5_mismatch_matrix.txt", 
            "start_gap1": "40", 
            "start_gap2": "40", 
            "stay_penalty": "1.000000", 
            "temp_bias": "1.000000", 
            "temp_weight": "1.000000", 
            "trace_categories_logs": "", 
            "trace_domains_config": "", 
            "trace_domains_log": "", 
            "trim_barcodes": "0", 
            "trim_min_events": "3", 
            "trim_strategy": "dna", 
            "trim_threshold": "2.500000", 
            "u_substitution": "0", 
            "verbose_logs": "1"
        }, 
        "read_count": 1, 
        "reads_per_channel_dist": [
            {
                "channel": 139, 
                "count": 1
            }
        ], 
        "run_id": "87b136ffc8ea5a243bdcff637a644011b53b6120", 
        "segment_duration": 60, 
        "segment_number": 15, 
        "segment_type": "guppy-acquisition", 
        "software": {
            "analysis": "1d_basecalling", 
            "name": "guppy-basecalling", 
            "version": "5.0.16+b9fcd7b5b"
        }, 
        "tracking_id": {
            "asic_id": "153816617", 
            "asic_id_17": "69161", 
            "asic_id_eeprom": "1867072", 
            "asic_temp": "31.0771847", 
            "auto_update_source": "https://mirror.oxfordnanoportal.com/software/MinKNOW/", 
            "bream_is_standard": "1", 
            "device_id": "MN17519", 
            "exp_script_hash": "a4e44ab9a2f835443be38062fe79e547271013be", 
            "exp_script_name": "NC_48Hr_Sequencing_Run_FLO_MIN104.py", 
            "exp_script_purpose": "sequencing_run", 
            "exp_start_time": "1466170880", 
            "flow_cell_id": "", 
            "heatsink_temp": "34.0273438", 
            "hostname": "kelvin", 
            "installation_type": "map", 
            "msg_id": "0ec065fd-463a-4ac5-9308-dee4632c3788", 
            "operating_system": "Windows 6.1", 
            "protocol_run_id": "db0dbed2-2a48-4be5-b5bd-26c042ab3c74", 
            "protocols_version_name": "0.51.3.40", 
            "run_id": "87b136ffc8ea5a243bdcff637a644011b53b6120", 
            "time_stamp": "2021-12-14T14:05:13Z", 
            "version": "0.51.3.40 b201605171140", 
            "version_name": "0.51.3.40 b201605171140"
        }
    }, 
    {
        "aggregation": "cumulative", 
        "analysis_id": "ffa802df-91b1-475c-b9d5-5dc3d2df847c", 
        "basecall_1d": {
            "exit_status_dist": {
                "fail:qscore_filter": 1, 
                "pass": 1
            }, 
            "qscore_dist_temp": [
                {
                    "count": 1, 
                    "mean_qscore": 6.5
                }, 
                {
                    "count": 1, 
                    "mean_qscore": 10.0
                }
            ], 
            "qscore_sum_temp": {
                "count": 2, 
                "mean": 8.608805656433105, 
                "sum": 17.21761131286621
            }, 
            "read_len_events_sum_temp": 56587, 
            "seq_len_bases_dist_temp": [
                {
                    "count": 2, 
                    "length": 0.0
                }
            ], 
            "seq_len_bases_sum_temp": 2, 
            "seq_len_events_dist_temp": [
                {
                    "count": 1, 
                    "length": 25000.0
                }, 
                {
                    "count": 1, 
                    "length": 31000.0
                }
            ], 
            "speed_bases_per_second_dist_temp": [
                {
                    "count": 2, 
                    "speed": 1.0
                }
            ], 
            "strand_median_pa": {
                "count": 2, 
                "mean": 92.07124328613281, 
                "sum": 184.14248657226562
            }, 
            "strand_sd_pa": {
                "count": 2, 
                "mean": 9.1721830368042, 
                "sum": 18.3443660736084
            }
        }, 
        "channel_count": 2, 
        "context_tags": {
            "experiment_kit": "genomic_dna", 
            "filename": "kelvin_20160617_fn_mn17519_sequencing_run_sample_id_74930", 
            "sample_frequency": "4000", 
            "user_filename_input": "sample_id"
        }, 
        "latest_run_time": 53696.890625, 
        "levels_sums": {
            "count": 2, 
            "mean": 0.0, 
            "open_pore_level_sum": 0.0
        }, 
        "opts": {
            "adapter_pt_range_scale": "5.200000", 
            "additional_context_bases": "2", 
            "align_ref": "", 
            "align_type": "auto", 
            "allow_inferior_barcodes": "0", 
            "arrangements_files": "barcode_arrs_pcr12.cfg barcode_arrs_pcr96.cfg barcode_arrs_nb12.cfg barcode_arrs_nb13-24.cfg barcode_arrs_nb24.cfg barcode_arrs_nb96.cfg barcode_arrs_rbk.cfg barcode_arrs_lwb.cfg barcode_arrs_rlb.cfg barcode_arrs_rab.cfg barcode_arrs_rbk4.cfg barcode_arrs_rbk096.cfg barcode_arrs_vmk.cfg barcode_arrs_vmk2.cfg barcode_arrs_16s.cfg", 
            "as_cpu_threads_per_scaler": "2", 
            "as_gpu_runners_per_device": "2", 
            "as_model_file": "", 
            "as_num_scalers": "1", 
            "as_reads_per_runner": "32", 
            "bam_methylation_threshold": "5.000000", 
            "bam_out": "0", 
            "barcode_kits": "", 
            "beam_cut": "100.000000", 
            "beam_width": "32", 
            "bed_file": "", 
            "builtin_scripts": "1", 
            "calib_detect": "0", 
            "calib_max_sequence_length": "3800", 
            "calib_min_coverage": "0.600000", 
            "calib_min_sequence_length": "3000", 
            "calib_reference": "lambda_3.6kb.fasta", 
            "chunk_size": "2000", 
            "chunks_per_caller": "10000", 
            "chunks_per_runner": "256", 
            "client_id": "-1", 
            "compress_fastq": "1", 
            "cpu_threads_per_caller": "4", 
            "detect_mid_strand_adapter": "0", 
            "detect_mid_strand_barcodes": "0", 
            "device": "", 
            "disable_pings": "0", 
            "disable_qscore_filtering": "0", 
            "dmean_threshold": "1.000000", 
            "dmean_win_size": "2", 
            "end_gap1": "40", 
            "end_gap2": "40", 
            "extend_gap1": "40", 
            "extend_gap2": "160", 
            "fast5_out": "1", 
            "flowcell": "", 
            "front_window_size": "150", 
            "gpu_runners_per_device": "4", 
            "high_priority_threshold": "10", 
            "input_file_list": "", 
            "jump_threshold": "1.000000", 
            "kernel_path": "", 
            "kit": "", 
            "lamp_arrangements_files": "barcode_arrs_ncov8.cfg barcode_arrs_ncov96.cfg barcode_arrs_multivirus1.cfg barcode_arrs_multivirus8.cfg", 
            "lamp_kit": "", 
            "log_speed_frequency": "0", 
            "max_queued_reads": "2000", 
            "max_search_len": "1000", 
            "medium_priority_threshold": "4", 
            "min_length_lamp_context": "30", 
            "min_length_lamp_target": "70", 
            "min_qscore": "9.000000", 
            "min_score": "60.000000", 
            "min_score_lamp": "80.000000", 
            "min_score_lamp_mask": "50.000000", 
            "min_score_lamp_target": "50.000000", 
            "min_score_mask": "40.000000", 
            "min_score_mid_barcodes": "50.000000", 
            "min_score_rear_override": "60.000000", 
            "model_file": "template_r9.4.1_450bps_hac.jsn", 
            "nested_output_folder": "0", 
            "noisiest_section_scaling_max_size": "8000", 
            "num_alignment_threads": "4", 
            "num_barcode_threads": "4", 
            "num_barcoding_buffers": "96", 
            "num_callers": "2", 
            "num_extra_bases_trim": "0", 
            "num_mid_barcoding_buffers": "96", 
            "open_gap1": "40", 
            "open_gap2": "160", 
            "overlap": "50", 
            "override_scaling": "0", 
            "ping_segment_duration": "60", 
            "ping_url": "https://ping.oxfordnanoportal.com/basecall", 
            "post_out": "0", 
            "print_workflows": "0", 
            "progress_stats_frequency": "-1.000000", 
            "pt_median_offset": "2.500000", 
            "pt_minimum_read_start_index": "30", 
            "pt_required_adapter_drop": "30.000000", 
            "pt_scaling": "0", 
            "qscore_offset": "-0.172100", 
            "qscore_scale": "0.935600", 
            "quiet": "0", 
            "read_batch_size": "4000", 
            "read_id_list": "", 
            "rear_window_size": "150", 
            "records_per_fastq": "4000", 
            "recursive": "0", 
            "require_barcodes_both_ends": "0", 
            "resume": "0", 
            "reverse_sequence": "0", 
            "scaling_mad": "1.000000", 
            "scaling_med": "0.000000", 
            "score_matrix_filename": "5x5_mismatch_matrix.txt", 
            "start_gap1": "40", 
            "start_gap2": "40", 
            "stay_penalty": "1.000000", 
            "temp_bias": "1.000000", 
            "temp_weight": "1.000000", 
            "trace_categories_logs": "", 
            "trace_domains_config": "", 
            "trace_domains_log": "", 
            "trim_barcodes": "0", 
            "trim_min_events": "3", 
            "trim_strategy": "dna", 
            "trim_threshold": "2.500000", 
            "u_substitution": "0", 
            "verbose_logs": "1"
        }, 
        "read_count": 2, 
        "reads_per_channel_dist": [
            {
                "channel": 138, 
                "count": 1
            }, 
            {
                "channel": 139, 
                "count": 1
            }
        ], 
        "run_id": "87b136ffc8ea5a243bdcff637a644011b53b6120", 
        "segment_duration": 900, 
        "segment_number": 1, 
        "segment_type": "guppy-acquisition", 
        "software": {
            "analysis": "1d_basecalling", 
            "name": "guppy-basecalling", 
            "version": "5.0.16+b9fcd7b5b"
        }, 
        "tracking_id": {
            "asic_id": "153816617", 
            "asic_id_17": "69161", 
            "asic_id_eeprom": "1867072", 
            "asic_temp": "31.0771847", 
            "auto_update_source": "https://mirror.oxfordnanoportal.com/software/MinKNOW/", 
            "bream_is_standard": "1", 
            "device_id": "MN17519", 
            "exp_script_hash": "a4e44ab9a2f835443be38062fe79e547271013be", 
            "exp_script_name": "NC_48Hr_Sequencing_Run_FLO_MIN104.py", 
            "exp_script_purpose": "sequencing_run", 
            "exp_start_time": "1466170880", 
            "flow_cell_id": "", 
            "heatsink_temp": "34.0273438", 
            "hostname": "kelvin", 
            "installation_type": "map", 
            "msg_id": "3087ba77-82e1-4bba-b6ec-a4f408ca80e7", 
            "operating_system": "Windows 6.1", 
            "protocol_run_id": "db0dbed2-2a48-4be5-b5bd-26c042ab3c74", 
            "protocols_version_name": "0.51.3.40", 
            "run_id": "87b136ffc8ea5a243bdcff637a644011b53b6120", 
            "time_stamp": "2021-12-14T14:05:13Z", 
            "version": "0.51.3.40 b201605171140", 
            "version_name": "0.51.3.40 b201605171140"
        }
    }
]